<?php
	$conn=mysqli_connect('localhost','root','', 'alphaware','3306') or die(mysql_error());
?>
